import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
@st.cache_data
def load_data():
    url = "https://raw.githubusercontent.com/dicodingacademy/dicoding_dataset/main/students_performance/data.csv"
    data = pd.read_csv(url, delimiter=";")
    return data

data = load_data()

# Judul Aplikasi
st.title("Student Dropout Prediction System")

# Sidebar: Pilihan Input
st.sidebar.header("Model Parameters")
test_size = st.sidebar.slider("Test size", 0.1, 0.5, 0.3)

# Sidebar: Pilihan Kolom Fitur
features = st.sidebar.multiselect(
    "Pilih Fitur untuk Model",
    options=data.columns,
    default=['Age_at_enrollment', 'Curricular_units_1st_sem_approved', 'Scholarship_holder']
)

# Menampilkan data
st.header("Data Siswa")
st.write(data.head())

# Menampilkan informasi dataset
st.sidebar.header("Informasi Dataset")
st.sidebar.write(f"Jumlah Baris: {data.shape[0]}")
st.sidebar.write(f"Jumlah Kolom: {data.shape[1]}")

# Preprocessing: Encoding Status (Graduate = 1, Dropout = 0)
data['Status_encoded'] = data['Status'].apply(lambda x: 1 if x == 'Graduate' else 0)

# Menampilkan Grafik Distribusi Status
st.header("Distribusi Status Kelulusan")
fig, ax = plt.subplots()
sns.countplot(x='Status', data=data, ax=ax)
st.pyplot(fig)

# Membuat Model Prediksi
if len(features) > 0:
    # Pisahkan fitur dan target
    X = data[features]
    y = data['Status_encoded']
    
    # Split data menjadi training dan testing
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)
    
    # Membuat model Random Forest
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    
    # Prediksi dan menghitung akurasi
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    # Tampilkan hasil akurasi model
    st.subheader("Hasil Prediksi")
    st.write(f"Akurasi Model: {accuracy:.2f}")
    
    # Tampilkan prediksi contoh data
    st.subheader("Contoh Prediksi")
    pred_results = pd.DataFrame({
        'Fitur': X_test.index,
        'Prediksi': y_pred,
        'Status Sebenarnya': y_test
    })
    st.write(pred_results.head())
else:
    st.error("Pilih setidaknya satu fitur untuk model prediksi.")

# Sidebar: Informasi tambahan
st.sidebar.header("Tentang Prototipe")
st.sidebar.info(
    """
    Prototipe ini memprediksi status kelulusan siswa (Graduate atau Dropout) 
    menggunakan beberapa parameter yang dapat dipilih.
    Hasil akurasi akan diperbarui secara otomatis sesuai dengan pilihan parameter input.
    """
)
